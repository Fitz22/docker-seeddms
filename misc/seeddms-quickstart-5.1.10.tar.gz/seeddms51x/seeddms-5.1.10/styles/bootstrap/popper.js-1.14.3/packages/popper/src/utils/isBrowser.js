export default typeof window !== 'undefined' && typeof document !== 'undefined';
